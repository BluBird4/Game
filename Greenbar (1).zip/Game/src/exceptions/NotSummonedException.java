package exceptions;

public class NotSummonedException extends HearthstoneException {
	public NotSummonedException() {
		super();
	}
	public NotSummonedException(String s){
		super(s);
	}
	

}
