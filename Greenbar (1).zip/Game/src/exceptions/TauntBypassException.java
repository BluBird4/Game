 package exceptions;

public class TauntBypassException extends HearthstoneException {
	public TauntBypassException() {
		super();
	}
	public TauntBypassException(String s){
		super(s);
	}
	

}
