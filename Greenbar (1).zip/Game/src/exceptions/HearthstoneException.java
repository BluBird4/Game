package exceptions;

abstract public class HearthstoneException extends Exception {
	public HearthstoneException() {
		super();
	}
	public HearthstoneException(String s){
		super(s);
	}
	

}
