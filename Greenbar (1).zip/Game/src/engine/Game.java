package engine;

import java.util.Random;


import model.heroes.Hero;

public class Game {
	private Hero firstHero;
	private Hero secondHero;
	private Hero currentHero;
	private Hero opponent;
	
	
	public Game() {
	}

	public Game(Hero p1, Hero p2) {
		super();
		firstHero = p1;
		secondHero = p2;
		int x = (int)(2*Math.random()+1);
		if (x==1){
			currentHero=p1;
			opponent=p2;
			currentHero.setTotalManaCrystals(1);
		}
		else{
			currentHero=p2;
			opponent=p1;
			opponent.setTotalManaCrystals(1);
		}
	}

	public Hero getCurrentHero() {
		return currentHero;
	}

	public Hero getOpponent() {
		return opponent;
	}
	
	
	
	

}
