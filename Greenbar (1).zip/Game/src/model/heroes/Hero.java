package model.heroes;

import java.io.BufferedReader;
import java.util.HashSet;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import model.cards.Card;
import model.cards.Rarity;
import model.cards.minions.Icehowl;
import model.cards.minions.Minion;


public abstract class Hero {
private String name; 
private int currentHP;
private boolean heroPowerUsed;
private int totalManaCrystals;
private int currentManaCrystals;
private ArrayList<Card> deck;
private ArrayList<Minion> field;
private ArrayList<Card> hand;
private int fatigueDamage;

public String getName() {
	return name;
}

public int getCurrentHP() {
	return currentHP;
}
public void setCurrentHP(int currentHP) {
	if(currentHP>30) {
		this.currentHP=30;
		return;
	}
	this.currentHP=currentHP;
}

public Hero(String name) throws IOException{
	this.name = name;
	currentHP=30;
	this.heroPowerUsed=false;
	deck=new ArrayList<Card>();
	buildDeck();
}

public boolean isHeroPowerUsed() {
	return heroPowerUsed;
}
public void setHeroPowerUsed(boolean heroPowerUsed) {
	this.heroPowerUsed = heroPowerUsed;
}
public int getTotalManaCrystals() {
	return totalManaCrystals;
}
public void setTotalManaCrystals(int totalManaCrystals) {
	if(totalManaCrystals>10)
		this.totalManaCrystals=10;
	else if(totalManaCrystals<0)
		this.totalManaCrystals=0;
	else
		this.totalManaCrystals=totalManaCrystals;
}
public int getCurrentManaCrystals() {
	return currentManaCrystals;
}
public void setCurrentManaCrystals(int currentManaCrystals) {
	if(currentManaCrystals>10)
		this.currentManaCrystals=10;
	else if(currentManaCrystals<totalManaCrystals)
		this.currentManaCrystals=this.totalManaCrystals;
	else
		this.currentManaCrystals=currentManaCrystals;
		
}
public ArrayList<Card> getDeck() {
	return deck;
}
public ArrayList<Minion> getField() {
	return field;
}
public ArrayList<Card> getHand() {
	return hand;
}
public abstract void buildDeck() throws IOException;

public final static  ArrayList<Minion> getNeutralMinions(ArrayList<Minion> minions,int count){
	ArrayList<Minion> list=new ArrayList<Minion>();
	HashSet h=new HashSet();
	int y;
	Minion temp;
	boolean flag=false;
	for(int i=0;i<count&&minions.size()!=0;i++){
		Random r=new Random();
		y=r.nextInt(minions.size());
		temp=minions.get(y);
		if(temp.getRarity()!= Rarity.LEGENDARY){
			if(!(h.contains(temp))){
				list.add(temp);
				h.add(temp);
			}
			else{
				list.add(temp);
				minions.remove(temp);
			}
		}
		else{
			if(flag==false)
			{
				list.add(temp);
				minions.remove(temp);
			}
			else 
				i--;
		}
		//System.out.println(minions.size());
		
		
	}
	return list;
}
public final static ArrayList<Minion> getAllNeutralMinions(String filePath) throws IOException{
String currentLine = "";
ArrayList<Minion> list = new ArrayList<Minion>();
FileReader fileReader= new FileReader(filePath);
BufferedReader br = new BufferedReader(fileReader);
String[] s;

while ((currentLine = br.readLine()) != null) {
	s = currentLine.split(",");
	String n=s[0];
	int m=Integer.parseInt(s[1]);
	Rarity r = null;
	switch (s[2]){
		case "b" : r = Rarity.BASIC; break ;
		case "c" : r = Rarity.COMMON; break;
		case "r" : r = Rarity.RARE; break;
		case "e" : r = Rarity.EPIC; break;
		case "l" : r = Rarity.LEGENDARY; break;
	}
	int att=Integer.parseInt(s[3]);
	int mp=Integer.parseInt(s[4]);
	boolean t=Boolean.parseBoolean(s[5]);
	boolean d=Boolean.parseBoolean(s[6]);
	boolean c=Boolean.parseBoolean(s[7]);
	if(n.equals("Icehowl")){
		Icehowl minion = new Icehowl();
		list.add(minion);
		continue;
	}
	else
	list.add(new Minion(n,m,r,att,mp,t,d,c));
	
	
}
br.close();
return list;
}


}
