package model.heroes;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import model.cards.Card;
import model.cards.Rarity;
import model.cards.minions.Minion;
import model.cards.spells.KillCommand;
import model.cards.spells.MultiShot;

public class Hunter extends Hero{

    public Hunter() throws IOException {
    	super("Rexxar");
    }
    public void buildDeck() throws IOException{
    	
    	ArrayList<Card> hunter=this.getDeck();
    	ArrayList<Minion> m=getAllNeutralMinions("neutral_minions.csv");
    	ArrayList<Minion> nm=getNeutralMinions(m,15);
    	for(int i=0;i<15;i++){
    		hunter.add(nm.get(i));
    	}
    	hunter.add(new KillCommand());
    	hunter.add(new KillCommand());
    	hunter.add(new MultiShot());
    	hunter.add(new MultiShot());
    	hunter.add(new Minion("King Krush",9,Rarity.LEGENDARY,8,8, false, false, true));
    	Collections.shuffle(hunter);
    
    	
    	
    }}
   