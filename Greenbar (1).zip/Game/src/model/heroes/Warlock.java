package model.heroes;

import java.io.IOException;

import java.util.ArrayList;
import java.util.Collections;

import model.cards.Card;
import model.cards.Rarity;
import model.cards.minions.Minion;
import model.cards.spells.CurseOfWeakness;
import model.cards.spells.SiphonSoul;
import model.cards.spells.TwistingNether;

public class Warlock extends Hero{

    public Warlock() throws IOException {
        super("Gul'dan");
        
    }
    public void buildDeck() throws IOException{
    	ArrayList<Card> warlock=this.getDeck();
    	ArrayList<Minion> m=getAllNeutralMinions("neutral_minions.csv");
    	ArrayList<Minion> nm=getNeutralMinions(m,13);
    	for(int i=0;i<13;i++){
    		warlock.add(nm.get(i));
    	}
    	warlock.add(new CurseOfWeakness());
    	warlock.add(new CurseOfWeakness());
    	warlock.add(new SiphonSoul());
    	warlock.add(new SiphonSoul());
    	warlock.add(new TwistingNether());
    	warlock.add(new TwistingNether());
    	warlock.add(new Minion("Wilfred Fizzlebang",6,Rarity.LEGENDARY,4,4,false,false,false));
    	Collections.shuffle(warlock);
    }
    
}