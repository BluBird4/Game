package model.heroes;

import java.io.IOException;

import java.util.ArrayList;
import java.util.Collections;

import model.cards.Card;
import model.cards.Rarity;
import model.cards.minions.Minion;
import model.cards.spells.SealOfChampions;
import model.cards.spells.LevelUp;

public class Paladin extends Hero{

    public Paladin() throws IOException {
        super("Uther Lightbringer");
    }

    public void buildDeck() throws IOException{
    	ArrayList<Card> paladin=this.getDeck();
    	ArrayList<Minion> m=getAllNeutralMinions("neutral_minions.csv");
    	ArrayList<Minion> nm=getNeutralMinions(m,15);
    	for(int i=0;i<15;i++){
    		paladin.add(nm.get(i));
    	}
    	paladin.add(new SealOfChampions());
    	paladin.add(new SealOfChampions());
    	paladin.add(new LevelUp());
    	paladin.add(new LevelUp());
    	paladin.add(new Minion("Tirion Fordring",4,Rarity.LEGENDARY,6,6, true, true, false));
    	Collections.shuffle(paladin);
    }
    
}