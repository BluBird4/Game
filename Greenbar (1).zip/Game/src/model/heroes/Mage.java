package model.heroes;

import java.io.IOException;

import java.util.ArrayList;
import java.util.Collections;

import model.cards.Card;
import model.cards.Rarity;
import model.cards.minions.Minion;
import model.cards.spells.Flamestrike;
import model.cards.spells.Polymorph;
import model.cards.spells.Pyroblast;

public class Mage extends Hero{

    public Mage() throws IOException {
        super("Jaina Proudmoore");
        
    }
    public void buildDeck() throws IOException{
    	ArrayList<Card> mage= this.getDeck();
    	ArrayList<Minion> m=getAllNeutralMinions("neutral_minions.csv");
    	ArrayList<Minion> nm=getNeutralMinions(m,13);
    	for(int i=0;i<13;i++){
    		mage.add(nm.get(i));
    	}
    	mage.add(new Polymorph());
    	mage.add(new Polymorph());
    	mage.add(new Flamestrike());
    	mage.add(new Flamestrike());
    	mage.add(new Pyroblast());
    	mage.add(new Pyroblast());
    	mage.add(new Minion("Kalycgos",10,Rarity.LEGENDARY,4,12,false,false,false));
    	Collections.shuffle(mage);
    }
}