package model.heroes;

import java.io.IOException;

import java.util.ArrayList;
import java.util.Collections;

import model.cards.Card;
import model.cards.Rarity;
import model.cards.minions.Minion;
import model.cards.spells.DivineSpirit;
import model.cards.spells.HolyNova;
import model.cards.spells.ShadowWordDeath;

public class Priest extends Hero{

    public Priest() throws IOException {
        super("Anduin Wrynn");
    }
    public void buildDeck() throws IOException{
    	ArrayList<Card> priest=this.getDeck();
    	ArrayList<Minion> m=getAllNeutralMinions("neutral_minions.csv");
    	ArrayList<Minion> nm=getNeutralMinions(m,13);
    	for(int i=0;i<13;i++){
    		priest.add(nm.get(i));
    	}
    	priest.add(new DivineSpirit());
    	priest.add(new DivineSpirit());
    	priest.add(new HolyNova());
    	priest.add(new HolyNova());
    	priest.add(new ShadowWordDeath());
    	priest.add(new ShadowWordDeath());
    	priest.add(new Minion("Prophet Velen",7,Rarity.LEGENDARY,7,7, false, false, false));
    	Collections.shuffle(priest);
    }
    
}