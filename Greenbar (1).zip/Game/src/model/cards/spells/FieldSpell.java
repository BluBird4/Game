package model.cards.spells;

public interface FieldSpell {

}
