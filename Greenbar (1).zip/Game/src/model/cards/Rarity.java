package model.cards;

public enum Rarity {
BASIC,COMMON,RARE,EPIC,LEGENDARY;
}
